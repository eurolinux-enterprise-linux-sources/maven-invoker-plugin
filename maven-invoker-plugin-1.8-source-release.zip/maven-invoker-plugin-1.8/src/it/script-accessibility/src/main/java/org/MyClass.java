package org;

public class MyClass
{

    public static final String PUBLIC = "public";

    protected static final String PROTECTED = "protected";

    static final String PACKAGE = "package";

    private static final String PRIVATE = "private";

}
