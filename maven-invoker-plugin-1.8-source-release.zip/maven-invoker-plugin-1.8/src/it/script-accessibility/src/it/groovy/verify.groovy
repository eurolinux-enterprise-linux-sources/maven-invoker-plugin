import org.MyClass;

println MyClass.PUBLIC
println MyClass.PROTECTED
println MyClass.PACKAGE
println MyClass.PRIVATE
