import java.io.*
import java.util.*
import java.util.regex.*

println context

File touchFile = context.get( "touchFile" )
touchFile.createNewFile()

return true
