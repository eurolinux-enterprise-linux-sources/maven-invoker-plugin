import java.io.*
import java.util.*
import java.util.regex.*

context.put( "touchFile", new File( basedir, "touch.txt" ) )

println context
