package org;

public class MyUtils
{

    public static String getNothing()
    {
        return "nothing";
    }

}
